import argparse
import json
import sys
from inchi_identity.inchi.compare import compare_text_files, compare_pair, read_file_lines
from inchi_identity.inchi.config_loader import load_config, build_config_from_layers, apply_inchitrust
from inchi_identity.inchi.mgf_parser import SimpleMgfDeduplicator


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(
        prog="inchi",
        description="Metabolite identity comparison tool"
    )

    subparsers = parser.add_subparsers(dest="command")
    
    compare_parser = subparsers.add_parser("compare")
    compare_parser.add_argument("file1")
    compare_parser.add_argument("file2")
    compare_parser.add_argument(
        "--mode",
        choices=["pairwise", "cross"],
        default="pairwise"
    )
    compare_parser.add_argument("--config", default=None)
    compare_parser.add_argument(
        "--only-equal",
        action="store_true"
    )
    compare_parser.add_argument("--output_file", default=None)
    add_inchitrust_arg(compare_parser)

    pair_parser = subparsers.add_parser("compare-pair")
    pair_parser.add_argument("inchi1")
    pair_parser.add_argument("inchi2")
    pair_parser.add_argument("--config", default=None)
    add_inchitrust_arg(pair_parser)

    pair_layers_parser = subparsers.add_parser("compare-pair-layers")
    pair_layers_parser.add_argument("inchi1")
    pair_layers_parser.add_argument("inchi2")
    pair_layers_parser.add_argument(
        "--layers",
        nargs="+",
        required=True
    )
    pair_layers_parser.add_argument("--config", default=None)
    add_inchitrust_arg(pair_layers_parser)

    mgf_parser = subparsers.add_parser("compare-mgf")
    mgf_parser.add_argument("file1", help="First MGF file")
    mgf_parser.add_argument("file2", help="Second MGF file")
    mgf_parser.add_argument("--config", default=None)
    mgf_parser.add_argument(
        "--layer",
        default="COMPLETE_IDENTITY",
        help="Identity layer to use (default: COMPLETE_IDENTITY)"
    )
    mgf_parser.add_argument(
        "--output-mgf",
        default="unified.mgf",
        help="Output path for unified MGF file (default: unified.mgf)"
    )
    mgf_parser.add_argument(
        "--output-log",
        default="unification_log.json",
        help="Output path for unification log (default: unification_log.json)"
    )

    args = parser.parse_args()

    if args.command == "compare":
        config = load_config(args.config)
        config = apply_inchitrust(config, args.inchitrust)

        list1 = read_file_lines(args.file1)
        list2 = read_file_lines(args.file2)

        result = compare_text_files(list1, list2, config, mode=args.mode, only_equal=args.only_equal)

        if args.output_file:
            with open(args.output_file, "w") as f:
                json.dump(result, f, indent=2)
        else:
            print(json.dumps(result, indent=2))

    elif args.command == "compare-pair":
        config = load_config(args.config)
        config = apply_inchitrust(config, args.inchitrust)

        result = compare_pair(
            args.inchi1,
            args.inchi2,
            config
        )

        print(json.dumps(result, indent=2))

    elif args.command == "compare-pair-layers":
        base_config = load_config(args.config)
        base_config = apply_inchitrust(base_config, args.inchitrust)

        config = build_config_from_layers(
            args.layers,
            base_config
        )

        result = compare_pair(
            args.inchi1,
            args.inchi2,
            config
        )

        print(json.dumps(result, indent=2))

    elif args.command == "compare-mgf":
        config = load_config(args.config)
        
        deduplicator = SimpleMgfDeduplicator(layer=args.layer, config=config)
        
        result = deduplicator.process_files(
            args.file1,
            args.file2,
            output_mgf=args.output_mgf,
            output_log=args.output_log
        )
        
        print(json.dumps(result, indent=2))

    else:
        parser.print_help()


def add_inchitrust_arg(parser):
    parser.add_argument(
        "--inchitrust",
        help="Path to InChI Trust executable",
        default=None
    )

if __name__ == "__main__":
    main()